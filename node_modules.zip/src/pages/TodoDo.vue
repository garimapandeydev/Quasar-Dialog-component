<template>
  <div class="q-pa-md q-gutter-sm">
    <q-btn
      v-for="filter in backdropFilterList"
      :key="filter.label"
      color="primary"
      :label="filter.label"
      no-caps
      @click="filter.onClick"
    />

    <q-dialog v-model="dialog" :backdrop-filter="backdropFilter">
      <q-card>
        <!-- First Section: Location Icon -->
        <q-card-section class="q-pa-md  q-gutter-md text-center" >
          <q-icon name="location_on" size="lg" color="primary" />
        </q-card-section>

        <q-separator />
        <!-- Second Section: Greeting Text -->
        <q-card-section class="text-center q-pt-none">
          <div  class="text-h6" style="color: #9a0498a1;">Allow GPS?</div>
          <div class="text-subtitle2" style="color: #9a0498a1;">My App wants GPS access</div>
        </q-card-section>

        <q-separator />
        <!-- Third Section: Allow and Deny Buttons -->
        <q-card-actions align="around" class="q-pt-none " style="margin-top: 8px;">
          <q-btn color="primary" label="Allow" />
          <q-btn outline style="color: #9a0498a1;" label="Deny" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>
<script>
import { ref } from 'vue'

export default {
  setup () {
    /**
     * Values for backdrop-filter are the same as in the CSS specs.
     * The following list is not an exhaustive one.
     */
    const list = [
      'Click here',

    ]

    const dialog = ref(false)
    const backdropFilter = ref(null)

    return {
      dialog,
      backdropFilter,
      backdropFilterList: list.map(filter => ({
        label: filter,
        onClick: () => {
          backdropFilter.value = filter
          dialog.value = true
        }
      }))
    }
  }
}
</script>
