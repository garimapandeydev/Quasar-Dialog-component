<template>
  <q-page class=text-center  >
    <h5 style="color: #9a0498a1; margin-top:40px">Give me feedback for my work</h5>
  </q-page>
</template>

<script setup>
  // Add your script logic here if needed
</script>
